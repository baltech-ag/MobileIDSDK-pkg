#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class MIDSAction, MIDSAppSettings, MIDSAvailabilityStates, MIDSBackendSyncedStatisticsCollector, MIDSBackendSyncedStatisticsCollectorCompanion, MIDSBlePermissionStatus, MIDSBleService, MIDSBleState, MIDSCharacteristicHandlers, MIDSClose, MIDSCredential, MIDSCredentialCompanion, MIDSCryptoComponents, MIDSDeviceInfo, MIDSDeviceInfoCompanion, MIDSEncryptResult, MIDSGate, MIDSKotlinAbstractCoroutineContextElement, MIDSKotlinAbstractCoroutineContextKey<B, E>, MIDSKotlinArray<T>, MIDSKotlinByteArray, MIDSKotlinByteIterator, MIDSKotlinCancellationException, MIDSKotlinEnum<E>, MIDSKotlinEnumCompanion, MIDSKotlinException, MIDSKotlinIllegalStateException, MIDSKotlinKTypeProjection, MIDSKotlinKTypeProjectionCompanion, MIDSKotlinKVariance, MIDSKotlinNothing, MIDSKotlinRuntimeException, MIDSKotlinThrowable, MIDSKotlinUnit, MIDSKotlinx_coroutines_coreCoroutineDispatcher, MIDSKotlinx_coroutines_coreCoroutineDispatcherKey, MIDSKotlinx_datetimeDayOfWeek, MIDSKotlinx_datetimeDayOfWeekNames, MIDSKotlinx_datetimeDayOfWeekNamesCompanion, MIDSKotlinx_datetimeInstant, MIDSKotlinx_datetimeInstantCompanion, MIDSKotlinx_datetimeLocalDate, MIDSKotlinx_datetimeLocalDateCompanion, MIDSKotlinx_datetimeMonth, MIDSKotlinx_datetimeMonthNames, MIDSKotlinx_datetimeMonthNamesCompanion, MIDSKotlinx_datetimePadding, MIDSKotlinx_serialization_coreSerialKind, MIDSKotlinx_serialization_coreSerializersModule, MIDSKtor_client_coreHttpClient, MIDSKtor_client_coreHttpClientCall, MIDSKtor_client_coreHttpClientCallCompanion, MIDSKtor_client_coreHttpClientConfig<T>, MIDSKtor_client_coreHttpClientEngineConfig, MIDSKtor_client_coreHttpReceivePipeline, MIDSKtor_client_coreHttpReceivePipelinePhases, MIDSKtor_client_coreHttpRequestBuilder, MIDSKtor_client_coreHttpRequestBuilderCompanion, MIDSKtor_client_coreHttpRequestData, MIDSKtor_client_coreHttpRequestPipeline, MIDSKtor_client_coreHttpRequestPipelinePhases, MIDSKtor_client_coreHttpResponse, MIDSKtor_client_coreHttpResponseContainer, MIDSKtor_client_coreHttpResponseData, MIDSKtor_client_coreHttpResponsePipeline, MIDSKtor_client_coreHttpResponsePipelinePhases, MIDSKtor_client_coreHttpSendPipeline, MIDSKtor_client_coreHttpSendPipelinePhases, MIDSKtor_client_coreProxyConfig, MIDSKtor_eventsEventDefinition<T>, MIDSKtor_eventsEvents, MIDSKtor_httpContentType, MIDSKtor_httpContentTypeCompanion, MIDSKtor_httpHeaderValueParam, MIDSKtor_httpHeaderValueWithParameters, MIDSKtor_httpHeaderValueWithParametersCompanion, MIDSKtor_httpHeadersBuilder, MIDSKtor_httpHttpMethod, MIDSKtor_httpHttpMethodCompanion, MIDSKtor_httpHttpProtocolVersion, MIDSKtor_httpHttpProtocolVersionCompanion, MIDSKtor_httpHttpStatusCode, MIDSKtor_httpHttpStatusCodeCompanion, MIDSKtor_httpOutgoingContent, MIDSKtor_httpURLBuilder, MIDSKtor_httpURLBuilderCompanion, MIDSKtor_httpURLProtocol, MIDSKtor_httpURLProtocolCompanion, MIDSKtor_httpUrl, MIDSKtor_httpUrlCompanion, MIDSKtor_ioBuffer, MIDSKtor_ioBufferCompanion, MIDSKtor_ioByteReadPacket, MIDSKtor_ioByteReadPacketCompanion, MIDSKtor_ioChunkBuffer, MIDSKtor_ioChunkBufferCompanion, MIDSKtor_ioInput, MIDSKtor_ioInputCompanion, MIDSKtor_ioMemory, MIDSKtor_ioMemoryCompanion, MIDSKtor_utilsAttributeKey<T>, MIDSKtor_utilsGMTDate, MIDSKtor_utilsGMTDateCompanion, MIDSKtor_utilsMonth, MIDSKtor_utilsMonthCompanion, MIDSKtor_utilsPipeline<TSubject, TContext>, MIDSKtor_utilsPipelinePhase, MIDSKtor_utilsStringValuesBuilderImpl, MIDSKtor_utilsTypeInfo, MIDSKtor_utilsWeekDay, MIDSKtor_utilsWeekDayCompanion, MIDSLogHandler, MIDSLogHandlerLogEntry, MIDSMobileIdSdk, MIDSPermissionManager, MIDSPermissionManagerCompanion, MIDSPermissionResult, MIDSProtocolError, MIDSReader, MIDSSharing, MIDSState, MIDSStatisticsEndpoint, MIDSStatisticsEndpointCompanion, MIDSStatisticsValue, MIDSStatisticsValueCompanion, MIDSTlvFormatError, MIDSTlvValue, MIDSTriggerDetectorCompanion, MIDSTriggerDetectorTriggerResult, MIDSUUID, MIDSValId, MIDSValIdCompanion, UIViewController;

@protocol MIDSDatastore_coreDataStore, MIDSIMobileIdCrypto, MIDSIProtocol, MIDSIRssiDistributionReporter, MIDSKotlinAnnotation, MIDSKotlinAppendable, MIDSKotlinComparable, MIDSKotlinContinuation, MIDSKotlinContinuationInterceptor, MIDSKotlinCoroutineContext, MIDSKotlinCoroutineContextElement, MIDSKotlinCoroutineContextKey, MIDSKotlinFunction, MIDSKotlinIterator, MIDSKotlinKAnnotatedElement, MIDSKotlinKClass, MIDSKotlinKClassifier, MIDSKotlinKDeclarationContainer, MIDSKotlinKType, MIDSKotlinMapEntry, MIDSKotlinSequence, MIDSKotlinSuspendFunction0, MIDSKotlinSuspendFunction1, MIDSKotlinSuspendFunction2, MIDSKotlinx_coroutines_coreChildHandle, MIDSKotlinx_coroutines_coreChildJob, MIDSKotlinx_coroutines_coreCoroutineScope, MIDSKotlinx_coroutines_coreDisposableHandle, MIDSKotlinx_coroutines_coreFlow, MIDSKotlinx_coroutines_coreFlowCollector, MIDSKotlinx_coroutines_coreJob, MIDSKotlinx_coroutines_coreParentJob, MIDSKotlinx_coroutines_coreRunnable, MIDSKotlinx_coroutines_coreSelectClause, MIDSKotlinx_coroutines_coreSelectClause0, MIDSKotlinx_coroutines_coreSelectInstance, MIDSKotlinx_coroutines_coreSharedFlow, MIDSKotlinx_coroutines_coreStateFlow, MIDSKotlinx_datetimeClock, MIDSKotlinx_datetimeDateTimeFormat, MIDSKotlinx_datetimeDateTimeFormatBuilder, MIDSKotlinx_datetimeDateTimeFormatBuilderWithDate, MIDSKotlinx_serialization_coreCompositeDecoder, MIDSKotlinx_serialization_coreCompositeEncoder, MIDSKotlinx_serialization_coreDecoder, MIDSKotlinx_serialization_coreDeserializationStrategy, MIDSKotlinx_serialization_coreEncoder, MIDSKotlinx_serialization_coreKSerializer, MIDSKotlinx_serialization_coreSerialDescriptor, MIDSKotlinx_serialization_coreSerializationStrategy, MIDSKotlinx_serialization_coreSerializersModuleCollector, MIDSKtor_client_coreHttpClientEngine, MIDSKtor_client_coreHttpClientEngineCapability, MIDSKtor_client_coreHttpClientPlugin, MIDSKtor_client_coreHttpRequest, MIDSKtor_httpHeaders, MIDSKtor_httpHttpMessage, MIDSKtor_httpHttpMessageBuilder, MIDSKtor_httpParameters, MIDSKtor_httpParametersBuilder, MIDSKtor_ioByteReadChannel, MIDSKtor_ioCloseable, MIDSKtor_ioObjectPool, MIDSKtor_ioReadSession, MIDSKtor_utilsAttributes, MIDSKtor_utilsStringValues, MIDSKtor_utilsStringValuesBuilder, MIDSStatisticsCollector;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface MIDSBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface MIDSBase (MIDSBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface MIDSMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface MIDSMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorMIDSKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface MIDSNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface MIDSByte : MIDSNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface MIDSUByte : MIDSNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface MIDSShort : MIDSNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface MIDSUShort : MIDSNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface MIDSInt : MIDSNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface MIDSUInt : MIDSNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface MIDSLong : MIDSNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface MIDSULong : MIDSNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface MIDSFloat : MIDSNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface MIDSDouble : MIDSNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface MIDSBoolean : MIDSNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppSettings")))
@interface MIDSAppSettings : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)appSettings __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSAppSettings *shared __attribute__((swift_name("shared")));
- (id _Nullable)getKey:(NSString *)key __attribute__((swift_name("get(key:)")));
- (void)removeAll __attribute__((swift_name("removeAll()")));
- (void)setKey:(NSString *)key value:(id _Nullable)value __attribute__((swift_name("set(key:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleService")))
@interface MIDSBleService : MIDSBase
- (instancetype)initWithServiceUuid:(NSString *)serviceUuid characteristics:(NSDictionary<NSString *, MIDSCharacteristicHandlers *> *)characteristics __attribute__((swift_name("init(serviceUuid:characteristics:)"))) __attribute__((objc_designated_initializer));
- (MIDSBleState *)getState __attribute__((swift_name("getState()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)registerWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("register(completionHandler:)")));
- (MIDSBleService *)subscribeListener:(void (^)(MIDSBleState *))listener __attribute__((swift_name("subscribe(listener:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)unregisterWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("unregister(completionHandler:)")));
@property (readonly) NSDictionary<NSString *, MIDSCharacteristicHandlers *> *characteristics __attribute__((swift_name("characteristics")));
@property (readonly) NSString *serviceUuid __attribute__((swift_name("serviceUuid")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol MIDSKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface MIDSKotlinEnum<E> : MIDSBase <MIDSKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end


/**
 * Represents the current state of the BLE peripheral service.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleState")))
@interface MIDSBleState : MIDSKotlinEnum<MIDSBleState *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Represents the current state of the BLE peripheral service.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSBleState *ok __attribute__((swift_name("ok")));
@property (class, readonly) MIDSBleState *alreadyregistered __attribute__((swift_name("alreadyregistered")));
@property (class, readonly) MIDSBleState *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) MIDSBleState *bleunsupported __attribute__((swift_name("bleunsupported")));
@property (class, readonly) MIDSBleState *bledisabled __attribute__((swift_name("bledisabled")));
@property (class, readonly) MIDSBleState *bleunauthorized __attribute__((swift_name("bleunauthorized")));
+ (MIDSKotlinArray<MIDSBleState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSBleState *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Defines the handlers for a BLE characteristic's operations.
 * Each handler is optional - only provide handlers for operations your characteristic supports.
 *
 * @property readHandler Called when a client reads from this characteristic.
 *                      Should return the data to send to the client.
 *                      Receives the client ID as parameter (null if unknown).
 * @property writeHandler Called when a client writes to this characteristic.
 *                       Receives the written data and client ID (null if unknown).
 * @property subscribeHandler Called when a client subscribes/unsubscribes for notifications.
 *                           Receives a NotificationHandler (null for unsubscribe) and client ID.
 *                           Store the NotificationHandler to send notifications later.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CharacteristicHandlers")))
@interface MIDSCharacteristicHandlers : MIDSBase
- (instancetype)initWithReadHandler:(id<MIDSKotlinSuspendFunction1> _Nullable)readHandler writeHandler:(id<MIDSKotlinSuspendFunction2> _Nullable)writeHandler subscribeHandler:(id<MIDSKotlinSuspendFunction2> _Nullable)subscribeHandler __attribute__((swift_name("init(readHandler:writeHandler:subscribeHandler:)"))) __attribute__((objc_designated_initializer));
- (MIDSCharacteristicHandlers *)doCopyReadHandler:(id<MIDSKotlinSuspendFunction1> _Nullable)readHandler writeHandler:(id<MIDSKotlinSuspendFunction2> _Nullable)writeHandler subscribeHandler:(id<MIDSKotlinSuspendFunction2> _Nullable)subscribeHandler __attribute__((swift_name("doCopy(readHandler:writeHandler:subscribeHandler:)")));

/**
 * Defines the handlers for a BLE characteristic's operations.
 * Each handler is optional - only provide handlers for operations your characteristic supports.
 *
 * @property readHandler Called when a client reads from this characteristic.
 *                      Should return the data to send to the client.
 *                      Receives the client ID as parameter (null if unknown).
 * @property writeHandler Called when a client writes to this characteristic.
 *                       Receives the written data and client ID (null if unknown).
 * @property subscribeHandler Called when a client subscribes/unsubscribes for notifications.
 *                           Receives a NotificationHandler (null for unsubscribe) and client ID.
 *                           Store the NotificationHandler to send notifications later.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Defines the handlers for a BLE characteristic's operations.
 * Each handler is optional - only provide handlers for operations your characteristic supports.
 *
 * @property readHandler Called when a client reads from this characteristic.
 *                      Should return the data to send to the client.
 *                      Receives the client ID as parameter (null if unknown).
 * @property writeHandler Called when a client writes to this characteristic.
 *                       Receives the written data and client ID (null if unknown).
 * @property subscribeHandler Called when a client subscribes/unsubscribes for notifications.
 *                           Receives a NotificationHandler (null for unsubscribe) and client ID.
 *                           Store the NotificationHandler to send notifications later.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Defines the handlers for a BLE characteristic's operations.
 * Each handler is optional - only provide handlers for operations your characteristic supports.
 *
 * @property readHandler Called when a client reads from this characteristic.
 *                      Should return the data to send to the client.
 *                      Receives the client ID as parameter (null if unknown).
 * @property writeHandler Called when a client writes to this characteristic.
 *                       Receives the written data and client ID (null if unknown).
 * @property subscribeHandler Called when a client subscribes/unsubscribes for notifications.
 *                           Receives a NotificationHandler (null for unsubscribe) and client ID.
 *                           Store the NotificationHandler to send notifications later.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MIDSKotlinSuspendFunction1> _Nullable readHandler __attribute__((swift_name("readHandler")));
@property (readonly) id<MIDSKotlinSuspendFunction2> _Nullable subscribeHandler __attribute__((swift_name("subscribeHandler")));
@property (readonly) id<MIDSKotlinSuspendFunction2> _Nullable writeHandler __attribute__((swift_name("writeHandler")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceInfo")))
@interface MIDSDeviceInfo : MIDSBase
- (instancetype)initWithOs:(NSString *)os os_version:(NSString *)os_version phone_model:(NSString *)phone_model app_version:(NSString *)app_version __attribute__((swift_name("init(os:os_version:phone_model:app_version:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSDeviceInfoCompanion *companion __attribute__((swift_name("companion")));
- (MIDSDeviceInfo *)doCopyOs:(NSString *)os os_version:(NSString *)os_version phone_model:(NSString *)phone_model app_version:(NSString *)app_version __attribute__((swift_name("doCopy(os:os_version:phone_model:app_version:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *app_version __attribute__((swift_name("app_version")));
@property (readonly) NSString *os __attribute__((swift_name("os")));
@property (readonly) NSString *os_version __attribute__((swift_name("os_version")));
@property (readonly) NSString *phone_model __attribute__((swift_name("phone_model")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceInfo.Companion")))
@interface MIDSDeviceInfoCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSDeviceInfoCompanion *shared __attribute__((swift_name("shared")));
- (id<MIDSKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Status of BLE-related permissions
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BlePermissionStatus")))
@interface MIDSBlePermissionStatus : MIDSBase
- (instancetype)initWithBluetoothPermission:(MIDSPermissionResult *)bluetoothPermission bluetoothAdminPermission:(MIDSPermissionResult *)bluetoothAdminPermission locationPermission:(MIDSPermissionResult *)locationPermission bluetoothScanPermission:(MIDSPermissionResult *)bluetoothScanPermission bluetoothConnectPermission:(MIDSPermissionResult *)bluetoothConnectPermission bluetoothAdvertisePermission:(MIDSPermissionResult *)bluetoothAdvertisePermission __attribute__((swift_name("init(bluetoothPermission:bluetoothAdminPermission:locationPermission:bluetoothScanPermission:bluetoothConnectPermission:bluetoothAdvertisePermission:)"))) __attribute__((objc_designated_initializer));
- (MIDSBlePermissionStatus *)doCopyBluetoothPermission:(MIDSPermissionResult *)bluetoothPermission bluetoothAdminPermission:(MIDSPermissionResult *)bluetoothAdminPermission locationPermission:(MIDSPermissionResult *)locationPermission bluetoothScanPermission:(MIDSPermissionResult *)bluetoothScanPermission bluetoothConnectPermission:(MIDSPermissionResult *)bluetoothConnectPermission bluetoothAdvertisePermission:(MIDSPermissionResult *)bluetoothAdvertisePermission __attribute__((swift_name("doCopy(bluetoothPermission:bluetoothAdminPermission:locationPermission:bluetoothScanPermission:bluetoothConnectPermission:bluetoothAdvertisePermission:)")));

/**
 * Status of BLE-related permissions
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Status of BLE-related permissions
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Status of BLE-related permissions
 */
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Returns true if all required permissions are granted
 */
@property (readonly) BOOL allGranted __attribute__((swift_name("allGranted")));
@property (readonly) MIDSPermissionResult *bluetoothAdminPermission __attribute__((swift_name("bluetoothAdminPermission")));
@property (readonly) MIDSPermissionResult *bluetoothAdvertisePermission __attribute__((swift_name("bluetoothAdvertisePermission")));
@property (readonly) MIDSPermissionResult *bluetoothConnectPermission __attribute__((swift_name("bluetoothConnectPermission")));
@property (readonly) MIDSPermissionResult *bluetoothPermission __attribute__((swift_name("bluetoothPermission")));
@property (readonly) MIDSPermissionResult *bluetoothScanPermission __attribute__((swift_name("bluetoothScanPermission")));

/**
 * Returns true if any permission can be requested (not permanently denied)
 */
@property (readonly) BOOL canRequestPermissions __attribute__((swift_name("canRequestPermissions")));
@property (readonly) MIDSPermissionResult *locationPermission __attribute__((swift_name("locationPermission")));
@end


/**
 * iOS-specific implementation of permission manager
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionManager")))
@interface MIDSPermissionManager : MIDSBase
@property (class, readonly, getter=companion) MIDSPermissionManagerCompanion *companion __attribute__((swift_name("companion")));

/**
 * Check the current status of all BLE-related permissions
 * On iOS, BLE permissions are handled automatically by the system
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)checkBlePermissionsWithCompletionHandler:(void (^)(MIDSBlePermissionStatus * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("checkBlePermissions(completionHandler:)")));

/**
 * Check if BLE permissions are supported on this platform
 */
- (BOOL)isBlePermissionSupported __attribute__((swift_name("isBlePermissionSupported()")));

/**
 * Open the app settings page where users can manually grant permissions
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openAppSettingsWithCompletionHandler:(void (^)(MIDSBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("openAppSettings(completionHandler:)")));

/**
 * Request all required BLE permissions
 * On iOS, permissions are requested automatically when needed
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestBlePermissionsWithCompletionHandler:(void (^)(MIDSBlePermissionStatus * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("requestBlePermissions(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionManager.Companion")))
@interface MIDSPermissionManagerCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSPermissionManagerCompanion *shared __attribute__((swift_name("shared")));

/**
 * Create a PermissionManager instance for iOS
 * Returns an instance as iOS handles permissions automatically
 */
- (MIDSPermissionManager * _Nullable)create __attribute__((swift_name("create()")));
@end


/**
 * Result of a permission check or request operation
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PermissionResult")))
@interface MIDSPermissionResult : MIDSKotlinEnum<MIDSPermissionResult *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Result of a permission check or request operation
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSPermissionResult *granted __attribute__((swift_name("granted")));
@property (class, readonly) MIDSPermissionResult *denied __attribute__((swift_name("denied")));
@property (class, readonly) MIDSPermissionResult *permanentlyDenied __attribute__((swift_name("permanentlyDenied")));
@property (class, readonly) MIDSPermissionResult *notSupported __attribute__((swift_name("notSupported")));
+ (MIDSKotlinArray<MIDSPermissionResult *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSPermissionResult *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EncryptResult")))
@interface MIDSEncryptResult : MIDSBase
- (instancetype)initWithEncrypted:(MIDSKotlinByteArray *)encrypted gmac:(MIDSKotlinByteArray *)gmac __attribute__((swift_name("init(encrypted:gmac:)"))) __attribute__((objc_designated_initializer));
- (MIDSEncryptResult *)doCopyEncrypted:(MIDSKotlinByteArray *)encrypted gmac:(MIDSKotlinByteArray *)gmac __attribute__((swift_name("doCopy(encrypted:gmac:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MIDSKotlinByteArray *encrypted __attribute__((swift_name("encrypted")));
@property (readonly) MIDSKotlinByteArray *gmac __attribute__((swift_name("gmac")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface MIDSKotlinThrowable : MIDSBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (MIDSKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MIDSKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface MIDSKotlinException : MIDSKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecurityException")))
@interface MIDSSecurityException : MIDSKotlinException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Sharing")))
@interface MIDSSharing : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sharing __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSSharing *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)shareEmailTo:(NSArray<NSString *> *)to cc:(NSArray<NSString *> *)cc subject:(NSString *)subject body:(NSString *)body attachmentText:(NSString * _Nullable)attachmentText attachmentFilename:(NSString * _Nullable)attachmentFilename completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("shareEmail(to:cc:subject:body:attachmentText:attachmentFilename:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Action")))
@interface MIDSAction : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)action __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSAction *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t ConvenientAccess __attribute__((swift_name("ConvenientAccess")));
@property (readonly) int32_t ProvideDistance __attribute__((swift_name("ProvideDistance")));
@property (readonly) int32_t ReadCredential __attribute__((swift_name("ReadCredential")));
@property (readonly) int32_t RemoteTrigger __attribute__((swift_name("RemoteTrigger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AvailabilityStates")))
@interface MIDSAvailabilityStates : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)availabilityStates __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSAvailabilityStates *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DISABLED __attribute__((swift_name("DISABLED")));
@property (readonly) NSString *OK __attribute__((swift_name("OK")));
@property (readonly) NSString *PERMISSIONS_DENIED __attribute__((swift_name("PERMISSIONS_DENIED")));
@property (readonly) NSString *PERMISSIONS_PERMANENTLY_DENIED __attribute__((swift_name("PERMISSIONS_PERMANENTLY_DENIED")));
@property (readonly) NSString *PERMISSIONS_REQUIRED __attribute__((swift_name("PERMISSIONS_REQUIRED")));
@property (readonly) NSString *UNAUTHORIZED __attribute__((swift_name("UNAUTHORIZED")));
@property (readonly) NSString *UNDEFINED __attribute__((swift_name("UNDEFINED")));
@property (readonly) NSString *UNKNOWN __attribute__((swift_name("UNKNOWN")));
@property (readonly) NSString *UNSUPPORTED __attribute__((swift_name("UNSUPPORTED")));
@end

__attribute__((swift_name("StatisticsCollector")))
@protocol MIDSStatisticsCollector
@required

/**
 * Close the statistics collector and release any resources.
 * Default implementation does nothing.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("close(completionHandler:)")));
- (NSString * _Nullable)getTodaysStatisticsUuid __attribute__((swift_name("getTodaysStatisticsUuid()")));
- (void)incrementCounterEvent:(NSString *)event incrementBy:(int32_t)incrementBy __attribute__((swift_name("incrementCounter(event:incrementBy:)")));
- (void)setCounterEvent:(NSString *)event value:(int32_t)value __attribute__((swift_name("setCounter(event:value:)")));
- (void)setCounterOnlyOnceADayEvent:(NSString *)event value:(int32_t)value __attribute__((swift_name("setCounterOnlyOnceADay(event:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BackendSyncedStatisticsCollector")))
@interface MIDSBackendSyncedStatisticsCollector : MIDSBase <MIDSStatisticsCollector>
@property (class, readonly, getter=companion) MIDSBackendSyncedStatisticsCollectorCompanion *companion __attribute__((swift_name("companion")));

/**
 * Close the statistics collector and release resources.
 * Closes the HTTP client used for backend communication.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("close(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("flush(completionHandler:)")));
- (NSString * _Nullable)getTodaysStatisticsUuid __attribute__((swift_name("getTodaysStatisticsUuid()")));
- (void)incrementCounterEvent:(NSString *)event incrementBy:(int32_t)incrementBy __attribute__((swift_name("incrementCounter(event:incrementBy:)")));
- (void)setCounterEvent:(NSString *)event value:(int32_t)value __attribute__((swift_name("setCounter(event:value:)")));
- (void)setCounterOnlyOnceADayEvent:(NSString *)event value:(int32_t)value __attribute__((swift_name("setCounterOnlyOnceADay(event:value:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)transferToBackendIncludeToday:(BOOL)includeToday deviceInfo:(MIDSDeviceInfo *)deviceInfo completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("transferToBackend(includeToday:deviceInfo:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)transferToBackendOnDeviceInfoChangedWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("transferToBackendOnDeviceInfoChanged(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BackendSyncedStatisticsCollector.Companion")))
@interface MIDSBackendSyncedStatisticsCollectorCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSBackendSyncedStatisticsCollectorCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createDataStore:(id<MIDSDatastore_coreDataStore>)dataStore statisticsEndpoint:(MIDSStatisticsEndpoint * _Nullable)statisticsEndpoint httpClient:(MIDSKtor_client_coreHttpClient *)httpClient coroutineScope:(id<MIDSKotlinx_coroutines_coreCoroutineScope>)coroutineScope clock:(id<MIDSKotlinx_datetimeClock>)clock completionHandler:(void (^)(MIDSBackendSyncedStatisticsCollector * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("create(dataStore:statisticsEndpoint:httpClient:coroutineScope:clock:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Close")))
@interface MIDSClose : MIDSKotlinEnum<MIDSClose *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSClose *temporary __attribute__((swift_name("temporary")));
@property (class, readonly) MIDSClose *permanently __attribute__((swift_name("permanently")));
+ (MIDSKotlinArray<MIDSClose *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSClose *> *entries __attribute__((swift_name("entries")));
@property (readonly) int8_t value __attribute__((swift_name("value")));
@end


/**
 * Represents the components extracted from a project key for Mobile ID operations
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Credential")))
@interface MIDSCredential : MIDSBase
- (instancetype)initWithKeyComm:(MIDSKotlinByteArray *)keyComm keyInitblock:(MIDSKotlinByteArray *)keyInitblock credentialBytes:(MIDSKotlinByteArray *)credentialBytes onTrigger:(MIDSBoolean *(^ _Nullable)(void))onTrigger __attribute__((swift_name("init(keyComm:keyInitblock:credentialBytes:onTrigger:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSCredentialCompanion *companion __attribute__((swift_name("companion")));
- (MIDSCredential *)doCopyKeyComm:(MIDSKotlinByteArray *)keyComm keyInitblock:(MIDSKotlinByteArray *)keyInitblock credentialBytes:(MIDSKotlinByteArray *)credentialBytes onTrigger:(MIDSBoolean *(^ _Nullable)(void))onTrigger __attribute__((swift_name("doCopy(keyComm:keyInitblock:credentialBytes:onTrigger:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Represents the components extracted from a project key for Mobile ID operations
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MIDSKotlinByteArray *credentialBytes __attribute__((swift_name("credentialBytes")));
@property (readonly) MIDSKotlinByteArray *keyComm __attribute__((swift_name("keyComm")));
@property (readonly) MIDSKotlinByteArray *keyInitblock __attribute__((swift_name("keyInitblock")));
@property MIDSBoolean *(^ _Nullable onTrigger)(void) __attribute__((swift_name("onTrigger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Credential.Companion")))
@interface MIDSCredentialCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSCredentialCompanion *shared __attribute__((swift_name("shared")));

/**
 * Creates credential components from a project key and credential ID
 *
 * @param projectKey The project-wide 16-byte key
 * @param credentialId The credential ID string
 * @param onTrigger Optional callback for trigger authorization, defaults to true
 * @return Credential object with extracted keys and signed credential
 */
- (MIDSCredential *)createProjectKey:(MIDSKotlinByteArray *)projectKey credentialId:(NSString *)credentialId onTrigger:(MIDSBoolean *(^ _Nullable)(void))onTrigger __attribute__((swift_name("create(projectKey:credentialId:onTrigger:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CryptoComponents")))
@interface MIDSCryptoComponents : MIDSBase
- (instancetype)initWithId:(MIDSKotlinByteArray *)id commCrypto:(id<MIDSIMobileIdCrypto>)commCrypto initBlockCrypto:(id<MIDSIMobileIdCrypto>)initBlockCrypto __attribute__((swift_name("init(id:commCrypto:initBlockCrypto:)"))) __attribute__((objc_designated_initializer));
- (MIDSCryptoComponents *)doCopyId:(MIDSKotlinByteArray *)id commCrypto:(id<MIDSIMobileIdCrypto>)commCrypto initBlockCrypto:(id<MIDSIMobileIdCrypto>)initBlockCrypto __attribute__((swift_name("doCopy(id:commCrypto:initBlockCrypto:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MIDSIMobileIdCrypto> commCrypto __attribute__((swift_name("commCrypto")));
@property (readonly) MIDSKotlinByteArray *id __attribute__((swift_name("id")));
@property (readonly, getter=doInitBlockCrypto) id<MIDSIMobileIdCrypto> initBlockCrypto __attribute__((swift_name("initBlockCrypto")));
@end

__attribute__((swift_name("ProtocolError")))
@interface MIDSProtocolError : MIDSKotlinException
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CryptoError")))
@interface MIDSCryptoError : MIDSProtocolError
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Gate")))
@interface MIDSGate : MIDSBase
- (instancetype)initWithDisplayName:(NSString *)displayName trigger:(id<MIDSKotlinSuspendFunction0>)trigger __attribute__((swift_name("init(displayName:trigger:)"))) __attribute__((objc_designated_initializer));
- (MIDSGate *)doCopyDisplayName:(NSString *)displayName trigger:(id<MIDSKotlinSuspendFunction0>)trigger __attribute__((swift_name("doCopy(displayName:trigger:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *displayName __attribute__((swift_name("displayName")));
@property (readonly) id<MIDSKotlinSuspendFunction0> trigger __attribute__((swift_name("trigger")));
@end

__attribute__((swift_name("IMobileIdCrypto")))
@protocol MIDSIMobileIdCrypto
@required
- (MIDSKotlinByteArray *)decryptMessageCipherMessage:(MIDSKotlinByteArray *)cipherMessage __attribute__((swift_name("decryptMessage(cipherMessage:)")));
- (MIDSKotlinByteArray *)encryptMessagePlainMessage:(MIDSKotlinByteArray *)plainMessage __attribute__((swift_name("encryptMessage(plainMessage:)")));
- (void)injectDecryptRandomnessRandomValue:(MIDSKotlinByteArray *)randomValue __attribute__((swift_name("injectDecryptRandomness(randomValue:)")));
- (void)injectEncryptRandomnessRandomValue:(MIDSKotlinByteArray *)randomValue __attribute__((swift_name("injectEncryptRandomness(randomValue:)")));
@end

__attribute__((swift_name("IProtocol")))
@protocol MIDSIProtocol
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startCredential:(MIDSKotlinByteArray *)credential completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("start(credential:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)stopWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("stop(completionHandler:)")));
@property (readonly) NSString *availability __attribute__((swift_name("availability")));
@property (readonly) MIDSKotlinByteArray *credential __attribute__((swift_name("credential")));
@property id<MIDSKotlinSuspendFunction0> _Nullable onTrigger __attribute__((swift_name("onTrigger")));
@end

__attribute__((swift_name("IRssiDistributionReporter")))
@protocol MIDSIRssiDistributionReporter
@required
- (void)reportRssiRssi:(int32_t)rssi __attribute__((swift_name("reportRssi(rssi:)")));
- (void)reportSubscribe __attribute__((swift_name("reportSubscribe()")));
@end

__attribute__((swift_name("TlvFormatError")))
@interface MIDSTlvFormatError : MIDSProtocolError
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InvalidCmd")))
@interface MIDSInvalidCmd : MIDSTlvFormatError
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler")))
@interface MIDSLogHandler : MIDSBase
- (instancetype)initWithMaxAgeHours:(int32_t)maxAgeHours maxEntries:(int32_t)maxEntries debugMode:(BOOL)debugMode __attribute__((swift_name("init(maxAgeHours:maxEntries:debugMode:)"))) __attribute__((objc_designated_initializer));
- (void)addLogMessageMessage:(NSString *)message __attribute__((swift_name("addLogMessage(message:)")));
- (void)clearLogs __attribute__((swift_name("clearLogs()")));
- (NSString *)getFormattedLogs __attribute__((swift_name("getFormattedLogs()")));
- (NSArray<MIDSLogHandlerLogEntry *> *)getLogsSinceId:(MIDSInt * _Nullable)sinceId __attribute__((swift_name("getLogs(sinceId:)")));
@property BOOL debugMode __attribute__((swift_name("debugMode")));
@property (readonly) id<MIDSKotlinx_coroutines_coreStateFlow> latestLogIdFlow __attribute__((swift_name("latestLogIdFlow")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.LogEntry")))
@interface MIDSLogHandlerLogEntry : MIDSBase
- (instancetype)initWithId:(int32_t)id timestamp:(MIDSKotlinx_datetimeInstant *)timestamp message:(NSString *)message __attribute__((swift_name("init(id:timestamp:message:)"))) __attribute__((objc_designated_initializer));
- (MIDSLogHandlerLogEntry *)doCopyId:(int32_t)id timestamp:(MIDSKotlinx_datetimeInstant *)timestamp message:(NSString *)message __attribute__((swift_name("doCopy(id:timestamp:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSString *)getFormattedTimestamp __attribute__((swift_name("getFormattedTimestamp()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) MIDSKotlinx_datetimeInstant *timestamp __attribute__((swift_name("timestamp")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MobileIdBleProtocol")))
@interface MIDSMobileIdBleProtocol : MIDSBase <MIDSIProtocol>
- (instancetype)initWithCryptoFactory:(MIDSCryptoComponents *(^)(void))cryptoFactory statistics:(id<MIDSStatisticsCollector> _Nullable)statistics log:(void (^)(NSString *))log permissionManager:(MIDSPermissionManager * _Nullable)permissionManager __attribute__((swift_name("init(cryptoFactory:statistics:log:permissionManager:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startCredential:(MIDSKotlinByteArray *)credential completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("start(credential:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)stopWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("stop(completionHandler:)")));
@property (readonly) NSString *availability __attribute__((swift_name("availability")));
@property (readonly) id<MIDSKotlinx_coroutines_coreStateFlow> availabilityFlow __attribute__((swift_name("availabilityFlow")));
@property (readonly) MIDSKotlinByteArray *credential __attribute__((swift_name("credential")));
@property (readonly) MIDSCryptoComponents *(^cryptoFactory)(void) __attribute__((swift_name("cryptoFactory")));
@property (readonly) NSArray<MIDSGate *> *gates __attribute__((swift_name("gates")));
@property id<MIDSKotlinSuspendFunction0> _Nullable onGatesUpdate __attribute__((swift_name("onGatesUpdate")));
@property id<MIDSKotlinSuspendFunction0> _Nullable onTrigger __attribute__((swift_name("onTrigger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MobileIdCrypto")))
@interface MIDSMobileIdCrypto : MIDSBase <MIDSIMobileIdCrypto>
- (instancetype)initWithKey:(MIDSKotlinByteArray *)key continuousAad:(BOOL)continuousAad __attribute__((swift_name("init(key:continuousAad:)"))) __attribute__((objc_designated_initializer));
- (MIDSKotlinByteArray *)decryptMessageCipherMessage:(MIDSKotlinByteArray *)cipherMessage __attribute__((swift_name("decryptMessage(cipherMessage:)")));
- (MIDSKotlinByteArray *)encryptMessagePlainMessage:(MIDSKotlinByteArray *)plainMessage __attribute__((swift_name("encryptMessage(plainMessage:)")));
- (void)injectDecryptRandomnessRandomValue:(MIDSKotlinByteArray *)randomValue __attribute__((swift_name("injectDecryptRandomness(randomValue:)")));
- (void)injectEncryptRandomnessRandomValue:(MIDSKotlinByteArray *)randomValue __attribute__((swift_name("injectEncryptRandomness(randomValue:)")));
@end


/**
 * Main SDK class that provides all functionality to support Baltech Mobile ID
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MobileIdSdk")))
@interface MIDSMobileIdSdk : MIDSBase

/**
 * Main SDK class that provides all functionality to support Baltech Mobile ID
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Main SDK class that provides all functionality to support Baltech Mobile ID
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Disable statistics collection and release associated resources.
 *
 * This permanently disables statistics collection for this SDK instance.
 * Any unsent statistics data will be discarded immediately.
 *
 * This operation:
 * - Closes the HTTP client used for backend communication
 * - Sets the statistics collector to null
 * - Cannot be reversed - statistics remain disabled for the SDK instance lifetime
 *
 * If statistics were not enabled, this is a no-op.
 *
 * **Note:** Active BLE sessions will continue to function normally, but will no longer
 * collect statistics after this method is called.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)disableStatisticsWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("disableStatistics(completionHandler:)")));

/**
 * Open system settings where the user can manually grant permissions
 *
 * **When to use:** Call this when permissions are permanently denied (user checked "Don't ask again")
 * and you need the user to manually enable permissions in system settings.
 *
 * **Typical flow:**
 * 1. Check `availability` - if it's `PERMISSIONS_PERMANENTLY_DENIED`
 * 2. Show user a dialog explaining why permissions are needed
 * 3. Call this function to open system settings
 * 4. User grants permissions in settings and returns to your app
 *
 * @return true if settings were opened successfully, false if opening failed or not supported
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPermissionSettingsWithCompletionHandler:(void (^)(MIDSBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("openPermissionSettings(completionHandler:)")));

/**
 * Request all required BLE permissions
 *
 * **Note:** This function is typically NOT needed, as the SDK automatically checks and requests
 * permissions when you set the `credentials` property (which internally calls `start()`).
 *
 * **Use this function only when:**
 * - The user denied permissions initially and you want to manually retry the request
 * - You want explicit control over when permission dialogs appear
 *
 * @return true if permissions were granted, false otherwise
 *
 * @see canRequestPermissions to check if this platform supports permission requests
 * @see openPermissionSettings for permanently denied permissions
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestPermissionsWithCompletionHandler:(void (^)(MIDSBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("requestPermissions(completionHandler:)")));

/**
 * Send logs via email using the sharing driver
 *
 * @param subject Optional custom email subject. Defaults to "BALTECH Mobile ID support request"
 * @param message Optional custom message to include before device information. Defaults to "Mobile ID Log Report"
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendLogsSubject:(NSString * _Nullable)subject message:(NSString * _Nullable)message completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("sendLogs(subject:message:completionHandler:)")));

/**
 * Current Bluetooth availability status
 */
@property (readonly) NSString *availability __attribute__((swift_name("availability")));

/**
 * Availability status as a flow for reactive programming
 */
@property (readonly) id<MIDSKotlinx_coroutines_coreStateFlow> availabilityFlow __attribute__((swift_name("availabilityFlow")));
@property NSArray<MIDSCredential *> *credentials __attribute__((swift_name("credentials")));

/**
 * Enable debug mode to print log messages to console via println
 */
@property BOOL debugMode __attribute__((swift_name("debugMode")));
@property (readonly) MIDSLogHandler *logHandler __attribute__((swift_name("logHandler")));
@property void (^logger)(NSString *) __attribute__((swift_name("logger")));

/**
 * Callback that gets called when availability status changes
 */
@property void (^ _Nullable onAvailabilityChange)(NSString *) __attribute__((swift_name("onAvailabilityChange")));

/**
 * Callback that gets called when the list of readers is updated
 */
@property void (^ _Nullable onReadersUpdate)(void) __attribute__((swift_name("onReadersUpdate")));

/**
 * List of currently available readers (gates)
 */
@property (readonly) NSArray<MIDSReader *> *readers __attribute__((swift_name("readers")));
@end


/**
 * When working in "Remote" mode, each smartcard reader is represented by this object
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Reader")))
@interface MIDSReader : MIDSBase
- (instancetype)initWithDisplayName:(NSString *)displayName trigger:(void (^)(void))trigger __attribute__((swift_name("init(displayName:trigger:)"))) __attribute__((objc_designated_initializer));
- (MIDSReader *)doCopyDisplayName:(NSString *)displayName trigger:(void (^)(void))trigger __attribute__((swift_name("doCopy(displayName:trigger:)")));

/**
 * When working in "Remote" mode, each smartcard reader is represented by this object
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * When working in "Remote" mode, each smartcard reader is represented by this object
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * When working in "Remote" mode, each smartcard reader is represented by this object
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *displayName __attribute__((swift_name("displayName")));
@property (readonly) void (^trigger)(void) __attribute__((swift_name("trigger")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RssiDistributionReporter")))
@interface MIDSRssiDistributionReporter : MIDSBase <MIDSIRssiDistributionReporter>
- (instancetype)initWithStatistics:(id<MIDSStatisticsCollector>)statistics __attribute__((swift_name("init(statistics:)"))) __attribute__((objc_designated_initializer));
- (void)reportRssiRssi:(int32_t)rssi __attribute__((swift_name("reportRssi(rssi:)")));
- (void)reportSubscribe __attribute__((swift_name("reportSubscribe()")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Session")))
@interface MIDSSession : MIDSBase
- (instancetype)initWithCentralId:(NSString *)centralId crypto:(id<MIDSIMobileIdCrypto>)crypto actions:(int32_t)actions sendNotification:(id<MIDSKotlinSuspendFunction1>)sendNotification rawCred:(MIDSKotlinByteArray *)rawCred onTrigger:(id<MIDSKotlinSuspendFunction0> _Nullable)onTrigger statistics:(id<MIDSStatisticsCollector> _Nullable)statistics log:(void (^)(NSString *))log rssiDistReporter:(id<MIDSIRssiDistributionReporter> _Nullable)rssiDistReporter __attribute__((swift_name("init(centralId:crypto:actions:sendNotification:rawCred:onTrigger:statistics:log:rssiDistReporter:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)receiveMessage:(MIDSKotlinByteArray *)message completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("receive(message:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)requestStopWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("requestStop(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)triggerWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("trigger(completionHandler:)")));
@property (readonly) NSString * _Nullable displayName __attribute__((swift_name("displayName")));
@property (readonly) id<MIDSKotlinSuspendFunction0> _Nullable onTrigger __attribute__((swift_name("onTrigger")));
@property (readonly) MIDSKotlinByteArray *rawCred __attribute__((swift_name("rawCred")));
@property (readonly) id<MIDSKotlinSuspendFunction1> sendNotification __attribute__((swift_name("sendNotification")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("State")))
@interface MIDSState : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)state __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSState *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t Available __attribute__((swift_name("Available")));
@property (readonly) int32_t Interacted __attribute__((swift_name("Interacted")));
@property (readonly) int32_t Negotiated __attribute__((swift_name("Negotiated")));
@property (readonly) int32_t NonFirstDistance __attribute__((swift_name("NonFirstDistance")));
@property (readonly) int32_t Required __attribute__((swift_name("Required")));
@property (readonly) int32_t TriggerActive __attribute__((swift_name("TriggerActive")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StatisticsEndpoint")))
@interface MIDSStatisticsEndpoint : MIDSBase
- (instancetype)initWithUrl:(NSString *)url token:(NSString *)token __attribute__((swift_name("init(url:token:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSStatisticsEndpointCompanion *companion __attribute__((swift_name("companion")));
- (MIDSStatisticsEndpoint *)doCopyUrl:(NSString *)url token:(NSString *)token __attribute__((swift_name("doCopy(url:token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StatisticsEndpoint.Companion")))
@interface MIDSStatisticsEndpointCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSStatisticsEndpointCompanion *shared __attribute__((swift_name("shared")));
- (id<MIDSKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StatisticsValue")))
@interface MIDSStatisticsValue : MIDSBase
- (instancetype)initWithUuid:(NSString *)uuid date:(NSString *)date values:(NSDictionary<NSString *, MIDSInt *> *)values __attribute__((swift_name("init(uuid:date:values:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSStatisticsValueCompanion *companion __attribute__((swift_name("companion")));
- (MIDSStatisticsValue *)doCopyUuid:(NSString *)uuid date:(NSString *)date values:(NSDictionary<NSString *, MIDSInt *> *)values __attribute__((swift_name("doCopy(uuid:date:values:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *date __attribute__((swift_name("date")));
@property (readonly) NSString *uuid __attribute__((swift_name("uuid")));
@property (readonly) NSDictionary<NSString *, MIDSInt *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StatisticsValue.Companion")))
@interface MIDSStatisticsValueCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSStatisticsValueCompanion *shared __attribute__((swift_name("shared")));
- (id<MIDSKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TlvValue")))
@interface MIDSTlvValue : MIDSBase
- (instancetype)initWithValId:(int32_t)valId valData:(MIDSKotlinByteArray *)valData __attribute__((swift_name("init(valId:valData:)"))) __attribute__((objc_designated_initializer));
@property (readonly) MIDSKotlinByteArray *valData __attribute__((swift_name("valData")));
@property (readonly) int32_t valId __attribute__((swift_name("valId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TriggerDetector")))
@interface MIDSTriggerDetector : MIDSBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MIDSTriggerDetectorCompanion *companion __attribute__((swift_name("companion")));
- (MIDSTriggerDetectorTriggerResult *)checkRssi:(int32_t)rssi __attribute__((swift_name("check(rssi:)")));
@property NSString *mode __attribute__((swift_name("mode")));
@property int32_t rssiCalibrateConv __attribute__((swift_name("rssiCalibrateConv")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TriggerDetector.Companion")))
@interface MIDSTriggerDetectorCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSTriggerDetectorCompanion *shared __attribute__((swift_name("shared")));
- (int32_t)rssiCalibrateOriginRssi:(int32_t)originRssi __attribute__((swift_name("rssiCalibrate(originRssi:)")));
@property (readonly) int32_t CONVENIENCE_REMOVE_DIFF_THRESHOLD __attribute__((swift_name("CONVENIENCE_REMOVE_DIFF_THRESHOLD")));
@property (readonly) int32_t CONVENIENCE_TRIGGER_THRESHOLD __attribute__((swift_name("CONVENIENCE_TRIGGER_THRESHOLD")));
@property (readonly) int32_t REMOVE_DIFF_THRESHOLD __attribute__((swift_name("REMOVE_DIFF_THRESHOLD")));
@property (readonly) int32_t TRIGGER_THRESHOLD __attribute__((swift_name("TRIGGER_THRESHOLD")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TriggerDetector.TriggerResult")))
@interface MIDSTriggerDetectorTriggerResult : MIDSKotlinEnum<MIDSTriggerDetectorTriggerResult *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSTriggerDetectorTriggerResult *triggered __attribute__((swift_name("triggered")));
@property (class, readonly) MIDSTriggerDetectorTriggerResult *triggeredConvenience __attribute__((swift_name("triggeredConvenience")));
@property (class, readonly) MIDSTriggerDetectorTriggerResult *removed __attribute__((swift_name("removed")));
@property (class, readonly) MIDSTriggerDetectorTriggerResult *noChange __attribute__((swift_name("noChange")));
+ (MIDSKotlinArray<MIDSTriggerDetectorTriggerResult *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSTriggerDetectorTriggerResult *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UUID")))
@interface MIDSUUID : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)uUID __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSUUID *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *INIT __attribute__((swift_name("INIT")));
@property (readonly) NSString *RECV __attribute__((swift_name("RECV")));
@property (readonly) NSString *SEND __attribute__((swift_name("SEND")));
@property (readonly) NSString *SRV __attribute__((swift_name("SRV")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValId")))
@interface MIDSValId : MIDSKotlinEnum<MIDSValId *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSValIdCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MIDSValId *addappsessionrandomness __attribute__((swift_name("addappsessionrandomness")));
@property (class, readonly) MIDSValId *addrdrsessionrandomness __attribute__((swift_name("addrdrsessionrandomness")));
@property (class, readonly) MIDSValId *requiredactions __attribute__((swift_name("requiredactions")));
@property (class, readonly) MIDSValId *availableactions __attribute__((swift_name("availableactions")));
@property (class, readonly) MIDSValId *actualactions __attribute__((swift_name("actualactions")));
@property (class, readonly) MIDSValId *credential __attribute__((swift_name("credential")));
@property (class, readonly) MIDSValId *distance __attribute__((swift_name("distance")));
@property (class, readonly) MIDSValId *trigger __attribute__((swift_name("trigger")));
@property (class, readonly) MIDSValId *status __attribute__((swift_name("status")));
@property (class, readonly) MIDSValId *displayname __attribute__((swift_name("displayname")));
@property (class, readonly) MIDSValId *forceclose __attribute__((swift_name("forceclose")));
@property (class, readonly) MIDSValId *statisticslegacy __attribute__((swift_name("statisticslegacy")));
@property (class, readonly) MIDSValId *resetstatistics __attribute__((swift_name("resetstatistics")));
@property (class, readonly) MIDSValId *rssicorrection __attribute__((swift_name("rssicorrection")));
@property (class, readonly) MIDSValId *statistics __attribute__((swift_name("statistics")));
@property (class, readonly) MIDSValId *ackresetstatistics __attribute__((swift_name("ackresetstatistics")));
@property (class, readonly) MIDSValId *readerinfo __attribute__((swift_name("readerinfo")));
@property (class, readonly) MIDSValId *readerbootstatus __attribute__((swift_name("readerbootstatus")));
@property (class, readonly) MIDSValId *readerstatistics __attribute__((swift_name("readerstatistics")));
@property (class, readonly) MIDSValId *rssicorrectionconv __attribute__((swift_name("rssicorrectionconv")));
+ (MIDSKotlinArray<MIDSValId *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSValId *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValId.Companion")))
@interface MIDSValIdCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSValIdCompanion *shared __attribute__((swift_name("shared")));
- (MIDSValId * _Nullable)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@end

@interface MIDSMobileIdSdk (Extensions)

/**
 * Creates a UIViewController that displays the log viewer for iOS applications.
 * The UIViewController is a thin wrapper around the Compose-based LogView.
 *
 * @return A UIViewController that can be presented in iOS apps
 */
- (UIViewController *)createLogViewController __attribute__((swift_name("createLogViewController()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface MIDSKotlinByteArray : MIDSBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(MIDSByte *(^)(MIDSInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (MIDSKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

@interface MIDSKotlinByteArray (Extensions)
- (NSString *)toHexSeparator:(NSString *)separator __attribute__((swift_name("toHex(separator:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BackendSyncedStatisticsCollectorKt")))
@interface MIDSBackendSyncedStatisticsCollectorKt : MIDSBase
+ (NSArray<MIDSKotlinx_datetimeLocalDate *> *)getMissingDatesDateList:(NSArray<MIDSKotlinx_datetimeLocalDate *> *)dateList __attribute__((swift_name("getMissingDates(dateList:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceInfoKt")))
@interface MIDSDeviceInfoKt : MIDSBase
+ (NSString *)getAppName __attribute__((swift_name("getAppName()")));
+ (NSString *)getAppVersion __attribute__((swift_name("getAppVersion()")));
+ (NSString *)getDeviceId __attribute__((swift_name("getDeviceId()")));
+ (MIDSDeviceInfo *)getDeviceInfo __attribute__((swift_name("getDeviceInfo()")));
+ (NSString *)getDeviceManufacturer __attribute__((swift_name("getDeviceManufacturer()")));
+ (NSString *)getDeviceModel __attribute__((swift_name("getDeviceModel()")));
+ (NSString *)getOs __attribute__((swift_name("getOs()")));
+ (NSString *)getOsVersion __attribute__((swift_name("getOsVersion()")));
+ (NSString *)getSentryId __attribute__((swift_name("getSentryId()")));
+ (NSString *)getTheme __attribute__((swift_name("getTheme()")));
+ (BOOL)isSameDeviceInfoInfo1:(MIDSDeviceInfo * _Nullable)info1 info2:(MIDSDeviceInfo * _Nullable)info2 __attribute__((swift_name("isSameDeviceInfo(info1:info2:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHelpersKt")))
@interface MIDSLogHelpersKt : MIDSBase
+ (NSString *)cidCentralId:(NSString * _Nullable)centralId __attribute__((swift_name("cid(centralId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MobileIdBleProtocolKt")))
@interface MIDSMobileIdBleProtocolKt : MIDSBase
@property (class, readonly) int64_t MIN_RECONNECT_DELAY __attribute__((swift_name("MIN_RECONNECT_DELAY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecurityKt")))
@interface MIDSSecurityKt : MIDSBase
+ (MIDSKotlinByteArray *)aesCmacData:(MIDSKotlinByteArray *)data key:(MIDSKotlinByteArray *)key __attribute__((swift_name("aesCmac(data:key:)")));
+ (MIDSKotlinByteArray *)aesGcmDecryptEncrypted:(MIDSKotlinByteArray *)encrypted gmac:(MIDSKotlinByteArray *)gmac key:(MIDSKotlinByteArray *)key iv:(MIDSKotlinByteArray *)iv aad:(MIDSKotlinByteArray *)aad __attribute__((swift_name("aesGcmDecrypt(encrypted:gmac:key:iv:aad:)")));
+ (MIDSEncryptResult *)aesGcmEncryptPlain:(MIDSKotlinByteArray *)plain key:(MIDSKotlinByteArray *)key iv:(MIDSKotlinByteArray *)iv aad:(MIDSKotlinByteArray *)aad __attribute__((swift_name("aesGcmEncrypt(plain:key:iv:aad:)")));
+ (MIDSKotlinByteArray *)generateRandomDataCount:(int32_t)count __attribute__((swift_name("generateRandomData(count:)")));
+ (MIDSKotlinByteArray *)sha256Data:(MIDSKotlinByteArray *)data __attribute__((swift_name("sha256(data:)")));
+ (NSString *)uuidv4 __attribute__((swift_name("uuidv4()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SessionKt")))
@interface MIDSSessionKt : MIDSBase
+ (int32_t)decodeIntData:(MIDSKotlinByteArray *)data __attribute__((swift_name("decodeInt(data:)")));
+ (NSArray<MIDSTlvValue *> *)decodeTlvTlvBlock:(MIDSKotlinByteArray *)tlvBlock __attribute__((swift_name("decodeTlv(tlvBlock:)")));
+ (MIDSKotlinByteArray *)encodeInt32Int:(int32_t)int_ __attribute__((swift_name("encodeInt32(int:)")));
+ (MIDSKotlinByteArray *)encodeTlvMessage:(NSArray<MIDSTlvValue *> *)message __attribute__((swift_name("encodeTlv(message:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StatisticsCollectorKt")))
@interface MIDSStatisticsCollectorKt : MIDSBase
@property (class, readonly) NSArray<NSString *> *StatisticEvents __attribute__((swift_name("StatisticEvents")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface MIDSKotlinRuntimeException : MIDSKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface MIDSKotlinIllegalStateException : MIDSKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface MIDSKotlinCancellationException : MIDSKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface MIDSKotlinEnumCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface MIDSKotlinArray<T> : MIDSBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(MIDSInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<MIDSKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol MIDSKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol MIDSKotlinSuspendFunction1 <MIDSKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol MIDSKotlinSuspendFunction2 <MIDSKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol MIDSKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<MIDSKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MIDSKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol MIDSKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<MIDSKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<MIDSKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol MIDSKotlinx_serialization_coreKSerializer <MIDSKotlinx_serialization_coreSerializationStrategy, MIDSKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((swift_name("Datastore_coreDataStore")))
@protocol MIDSDatastore_coreDataStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDataTransform:(id<MIDSKotlinSuspendFunction1>)transform completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("updateData(transform:completionHandler:)")));
@property (readonly) id<MIDSKotlinx_coroutines_coreFlow> data __attribute__((swift_name("data")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol MIDSKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<MIDSKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol MIDSKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface MIDSKtor_client_coreHttpClient : MIDSBase <MIDSKotlinx_coroutines_coreCoroutineScope, MIDSKtor_ioCloseable>
- (instancetype)initWithEngine:(id<MIDSKtor_client_coreHttpClientEngine>)engine userConfig:(MIDSKtor_client_coreHttpClientConfig<MIDSKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (MIDSKtor_client_coreHttpClient *)configBlock:(void (^)(MIDSKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<MIDSKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MIDSKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<MIDSKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<MIDSKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) MIDSKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) MIDSKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) MIDSKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) MIDSKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) MIDSKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) MIDSKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((swift_name("Kotlinx_datetimeClock")))
@protocol MIDSKotlinx_datetimeClock
@required
- (MIDSKotlinx_datetimeInstant *)now __attribute__((swift_name("now()")));
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol MIDSKotlinSuspendFunction0 <MIDSKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol MIDSKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<MIDSKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol MIDSKotlinx_coroutines_coreSharedFlow <MIDSKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol MIDSKotlinx_coroutines_coreStateFlow <MIDSKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value_ __attribute__((swift_name("value_")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/InstantIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeInstant")))
@interface MIDSKotlinx_datetimeInstant : MIDSBase <MIDSKotlinComparable>
@property (class, readonly, getter=companion) MIDSKotlinx_datetimeInstantCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(MIDSKotlinx_datetimeInstant *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (MIDSKotlinx_datetimeInstant *)minusDuration:(int64_t)duration __attribute__((swift_name("minus(duration:)")));
- (int64_t)minusOther:(MIDSKotlinx_datetimeInstant *)other __attribute__((swift_name("minus(other:)")));
- (MIDSKotlinx_datetimeInstant *)plusDuration:(int64_t)duration __attribute__((swift_name("plus(duration:)")));
- (int64_t)toEpochMilliseconds __attribute__((swift_name("toEpochMilliseconds()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t epochSeconds __attribute__((swift_name("epochSeconds")));
@property (readonly) int32_t nanosecondsOfSecond __attribute__((swift_name("nanosecondsOfSecond")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol MIDSKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface MIDSKotlinByteIterator : MIDSBase <MIDSKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MIDSByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/LocalDateIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate")))
@interface MIDSKotlinx_datetimeLocalDate : MIDSBase <MIDSKotlinComparable>
- (instancetype)initWithYear:(int32_t)year monthNumber:(int32_t)monthNumber dayOfMonth:(int32_t)dayOfMonth __attribute__((swift_name("init(year:monthNumber:dayOfMonth:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithYear:(int32_t)year month:(MIDSKotlinx_datetimeMonth *)month dayOfMonth:(int32_t)dayOfMonth __attribute__((swift_name("init(year:month:dayOfMonth:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKotlinx_datetimeLocalDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(MIDSKotlinx_datetimeLocalDate *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int32_t)toEpochDays __attribute__((swift_name("toEpochDays()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) MIDSKotlinx_datetimeDayOfWeek *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) MIDSKotlinx_datetimeMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t monthNumber __attribute__((swift_name("monthNumber")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol MIDSKotlinx_serialization_coreEncoder
@required
- (id<MIDSKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<MIDSKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<MIDSKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<MIDSKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<MIDSKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) MIDSKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol MIDSKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<MIDSKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MIDSKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<MIDSKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) MIDSKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol MIDSKotlinx_serialization_coreDecoder
@required
- (id<MIDSKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<MIDSKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (MIDSKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<MIDSKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<MIDSKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) MIDSKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol MIDSKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<MIDSKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<MIDSKotlinCoroutineContextElement> _Nullable)getKey:(id<MIDSKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<MIDSKotlinCoroutineContext>)minusKeyKey:(id<MIDSKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<MIDSKotlinCoroutineContext>)plusContext:(id<MIDSKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol MIDSKtor_client_coreHttpClientEngine <MIDSKotlinx_coroutines_coreCoroutineScope, MIDSKtor_ioCloseable>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(MIDSKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(MIDSKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(MIDSKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) MIDSKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) MIDSKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<MIDSKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface MIDSKtor_client_coreHttpClientEngineConfig : MIDSBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property MIDSKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount"))) __attribute__((deprecated("The [threadsCount] property is deprecated. The [Dispatchers.IO] is used by default.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface MIDSKtor_client_coreHttpClientConfig<T> : MIDSBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MIDSKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(MIDSKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<MIDSKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(MIDSKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(MIDSKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol MIDSKtor_client_coreHttpClientEngineCapability
@required
@end

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol MIDSKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(MIDSKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(MIDSKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<MIDSKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface MIDSKtor_eventsEvents : MIDSBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(MIDSKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<MIDSKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(MIDSKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(MIDSKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface MIDSKtor_utilsPipeline<TSubject, TContext> : MIDSBase
- (instancetype)initWithPhases:(MIDSKotlinArray<MIDSKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(MIDSKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<MIDSKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(MIDSKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(MIDSKtor_utilsPipelinePhase *)reference phase:(MIDSKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(MIDSKtor_utilsPipelinePhase *)reference phase:(MIDSKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(MIDSKtor_utilsPipelinePhase *)phase block:(id<MIDSKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<MIDSKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(MIDSKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(MIDSKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(MIDSKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(MIDSKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
@property (readonly) id<MIDSKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<MIDSKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface MIDSKtor_client_coreHttpReceivePipeline : MIDSKtor_utilsPipeline<MIDSKtor_client_coreHttpResponse *, MIDSKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(MIDSKotlinArray<MIDSKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(MIDSKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<MIDSKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface MIDSKtor_client_coreHttpRequestPipeline : MIDSKtor_utilsPipeline<id, MIDSKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(MIDSKotlinArray<MIDSKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(MIDSKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<MIDSKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface MIDSKtor_client_coreHttpResponsePipeline : MIDSKtor_utilsPipeline<MIDSKtor_client_coreHttpResponseContainer *, MIDSKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(MIDSKotlinArray<MIDSKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(MIDSKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<MIDSKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface MIDSKtor_client_coreHttpSendPipeline : MIDSKtor_utilsPipeline<id, MIDSKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(MIDSKotlinArray<MIDSKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(MIDSKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<MIDSKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol MIDSKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeInstant.Companion")))
@interface MIDSKotlinx_datetimeInstantCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinx_datetimeInstantCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKotlinx_datetimeInstant *)fromEpochMillisecondsEpochMilliseconds:(int64_t)epochMilliseconds __attribute__((swift_name("fromEpochMilliseconds(epochMilliseconds:)")));
- (MIDSKotlinx_datetimeInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment:(int32_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment:)")));
- (MIDSKotlinx_datetimeInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment_:(int64_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment_:)")));
- (MIDSKotlinx_datetimeInstant *)now __attribute__((swift_name("now()"))) __attribute__((unavailable("Use Clock.System.now() instead")));
- (MIDSKotlinx_datetimeInstant *)parseInput:(id)input format:(id<MIDSKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("parse(input:format:)")));
- (id<MIDSKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) MIDSKotlinx_datetimeInstant *DISTANT_FUTURE __attribute__((swift_name("DISTANT_FUTURE")));
@property (readonly) MIDSKotlinx_datetimeInstant *DISTANT_PAST __attribute__((swift_name("DISTANT_PAST")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonth")))
@interface MIDSKotlinx_datetimeMonth : MIDSKotlinEnum<MIDSKotlinx_datetimeMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSKotlinx_datetimeMonth *january __attribute__((swift_name("january")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *february __attribute__((swift_name("february")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *march __attribute__((swift_name("march")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *april __attribute__((swift_name("april")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *may __attribute__((swift_name("may")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *june __attribute__((swift_name("june")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *july __attribute__((swift_name("july")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *august __attribute__((swift_name("august")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *september __attribute__((swift_name("september")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *october __attribute__((swift_name("october")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *november __attribute__((swift_name("november")));
@property (class, readonly) MIDSKotlinx_datetimeMonth *december __attribute__((swift_name("december")));
+ (MIDSKotlinArray<MIDSKotlinx_datetimeMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSKotlinx_datetimeMonth *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate.Companion")))
@interface MIDSKotlinx_datetimeLocalDateCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinx_datetimeLocalDateCompanion *shared __attribute__((swift_name("shared")));
- (id<MIDSKotlinx_datetimeDateTimeFormat>)FormatBlock:(void (^)(id<MIDSKotlinx_datetimeDateTimeFormatBuilderWithDate>))block __attribute__((swift_name("Format(block:)")));
- (MIDSKotlinx_datetimeLocalDate *)fromEpochDaysEpochDays:(int32_t)epochDays __attribute__((swift_name("fromEpochDays(epochDays:)")));
- (MIDSKotlinx_datetimeLocalDate *)parseInput:(id)input format:(id<MIDSKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("parse(input:format:)")));
- (id<MIDSKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeek")))
@interface MIDSKotlinx_datetimeDayOfWeek : MIDSKotlinEnum<MIDSKotlinx_datetimeDayOfWeek *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *monday __attribute__((swift_name("monday")));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *friday __attribute__((swift_name("friday")));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) MIDSKotlinx_datetimeDayOfWeek *sunday __attribute__((swift_name("sunday")));
+ (MIDSKotlinArray<MIDSKotlinx_datetimeDayOfWeek *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSKotlinx_datetimeDayOfWeek *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol MIDSKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<MIDSKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<MIDSKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<MIDSKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) MIDSKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface MIDSKotlinx_serialization_coreSerializersModule : MIDSBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<MIDSKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MIDSKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<MIDSKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<MIDSKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MIDSKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<MIDSKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MIDSKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<MIDSKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol MIDSKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface MIDSKotlinx_serialization_coreSerialKind : MIDSBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol MIDSKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<MIDSKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<MIDSKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<MIDSKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<MIDSKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) MIDSKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface MIDSKotlinNothing : MIDSBase
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol MIDSKotlinCoroutineContextElement <MIDSKotlinCoroutineContext>
@required
@property (readonly) id<MIDSKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol MIDSKotlinCoroutineContextKey
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface MIDSKtor_client_coreHttpRequestData : MIDSBase
- (instancetype)initWithUrl:(MIDSKtor_httpUrl *)url method:(MIDSKtor_httpHttpMethod *)method headers:(id<MIDSKtor_httpHeaders>)headers body:(MIDSKtor_httpOutgoingContent *)body executionContext:(id<MIDSKotlinx_coroutines_coreJob>)executionContext attributes:(id<MIDSKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<MIDSKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MIDSKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) MIDSKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<MIDSKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<MIDSKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) MIDSKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) MIDSKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface MIDSKtor_client_coreHttpResponseData : MIDSBase
- (instancetype)initWithStatusCode:(MIDSKtor_httpHttpStatusCode *)statusCode requestTime:(MIDSKtor_utilsGMTDate *)requestTime headers:(id<MIDSKtor_httpHeaders>)headers version:(MIDSKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<MIDSKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<MIDSKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<MIDSKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) MIDSKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) MIDSKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) MIDSKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface MIDSKotlinAbstractCoroutineContextElement : MIDSBase <MIDSKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<MIDSKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<MIDSKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol MIDSKotlinContinuationInterceptor <MIDSKotlinCoroutineContextElement>
@required
- (id<MIDSKotlinContinuation>)interceptContinuationContinuation:(id<MIDSKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<MIDSKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface MIDSKotlinx_coroutines_coreCoroutineDispatcher : MIDSKotlinAbstractCoroutineContextElement <MIDSKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<MIDSKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<MIDSKotlinCoroutineContext>)context block:(id<MIDSKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<MIDSKotlinCoroutineContext>)context block:(id<MIDSKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<MIDSKotlinContinuation>)interceptContinuationContinuation:(id<MIDSKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<MIDSKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (MIDSKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (MIDSKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(MIDSKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<MIDSKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface MIDSKtor_client_coreProxyConfig : MIDSBase
- (instancetype)initWithUrl:(MIDSKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MIDSKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol MIDSKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(MIDSKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) MIDSKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface MIDSKtor_utilsAttributeKey<T> : MIDSBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface MIDSKtor_eventsEventDefinition<T> : MIDSBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol MIDSKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface MIDSKtor_utilsPipelinePhase : MIDSBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface MIDSKtor_client_coreHttpReceivePipelinePhases : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) MIDSKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol MIDSKtor_httpHttpMessage
@required
@property (readonly) id<MIDSKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface MIDSKtor_client_coreHttpResponse : MIDSBase <MIDSKtor_httpHttpMessage, MIDSKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MIDSKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<MIDSKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) MIDSKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) MIDSKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) MIDSKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface MIDSKotlinUnit : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface MIDSKtor_client_coreHttpRequestPipelinePhases : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) MIDSKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol MIDSKtor_httpHttpMessageBuilder
@required
@property (readonly) MIDSKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface MIDSKtor_client_coreHttpRequestBuilder : MIDSBase <MIDSKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MIDSKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<MIDSKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<MIDSKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<MIDSKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (MIDSKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(MIDSKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (MIDSKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(MIDSKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(MIDSKtor_httpURLBuilder *, MIDSKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<MIDSKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property MIDSKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<MIDSKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) MIDSKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property MIDSKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) MIDSKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface MIDSKtor_client_coreHttpResponsePipelinePhases : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) MIDSKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface MIDSKtor_client_coreHttpResponseContainer : MIDSBase
- (instancetype)initWithExpectedType:(MIDSKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (MIDSKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(MIDSKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MIDSKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface MIDSKtor_client_coreHttpClientCall : MIDSBase <MIDSKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(MIDSKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(MIDSKtor_client_coreHttpClient *)client requestData:(MIDSKtor_client_coreHttpRequestData *)requestData responseData:(MIDSKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(MIDSKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(MIDSKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<MIDSKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<MIDSKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) MIDSKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<MIDSKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<MIDSKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property MIDSKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface MIDSKtor_client_coreHttpSendPipelinePhases : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) MIDSKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) MIDSKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormat")))
@protocol MIDSKotlinx_datetimeDateTimeFormat
@required
- (NSString *)formatValue:(id _Nullable)value __attribute__((swift_name("format(value:)")));
- (id<MIDSKotlinAppendable>)formatToAppendable:(id<MIDSKotlinAppendable>)appendable value:(id _Nullable)value __attribute__((swift_name("formatTo(appendable:value:)")));
- (id _Nullable)parseInput:(id)input __attribute__((swift_name("parse(input:)")));
- (id _Nullable)parseOrNullInput:(id)input __attribute__((swift_name("parseOrNull(input:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilder")))
@protocol MIDSKotlinx_datetimeDateTimeFormatBuilder
@required
- (void)charsValue:(NSString *)value __attribute__((swift_name("chars(value:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilderWithDate")))
@protocol MIDSKotlinx_datetimeDateTimeFormatBuilderWithDate <MIDSKotlinx_datetimeDateTimeFormatBuilder>
@required
- (void)dateFormat:(id<MIDSKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("date(format:)")));
- (void)dayOfMonthPadding:(MIDSKotlinx_datetimePadding *)padding __attribute__((swift_name("dayOfMonth(padding:)")));
- (void)dayOfWeekNames:(MIDSKotlinx_datetimeDayOfWeekNames *)names __attribute__((swift_name("dayOfWeek(names:)")));
- (void)monthNameNames:(MIDSKotlinx_datetimeMonthNames *)names __attribute__((swift_name("monthName(names:)")));
- (void)monthNumberPadding:(MIDSKotlinx_datetimePadding *)padding __attribute__((swift_name("monthNumber(padding:)")));
- (void)yearPadding:(MIDSKotlinx_datetimePadding *)padding __attribute__((swift_name("year(padding:)")));
- (void)yearTwoDigitsBaseYear:(int32_t)baseYear __attribute__((swift_name("yearTwoDigits(baseYear:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol MIDSKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<MIDSKotlinKClass>)kClass provider:(id<MIDSKotlinx_serialization_coreKSerializer> (^)(NSArray<id<MIDSKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<MIDSKotlinKClass>)kClass serializer:(id<MIDSKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<MIDSKotlinKClass>)baseClass actualClass:(id<MIDSKotlinKClass>)actualClass actualSerializer:(id<MIDSKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<MIDSKotlinKClass>)baseClass defaultDeserializerProvider:(id<MIDSKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<MIDSKotlinKClass>)baseClass defaultDeserializerProvider:(id<MIDSKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<MIDSKotlinKClass>)baseClass defaultSerializerProvider:(id<MIDSKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol MIDSKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol MIDSKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol MIDSKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol MIDSKotlinKClass <MIDSKotlinKDeclarationContainer, MIDSKotlinKAnnotatedElement, MIDSKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface MIDSKtor_httpUrl : MIDSBase
@property (class, readonly, getter=companion) MIDSKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<MIDSKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) MIDSKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface MIDSKtor_httpHttpMethod : MIDSBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol MIDSKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<MIDSKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol MIDSKtor_httpHeaders <MIDSKtor_utilsStringValues>
@required
@end

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface MIDSKtor_httpOutgoingContent : MIDSBase
- (id _Nullable)getPropertyKey:(MIDSKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(MIDSKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<MIDSKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) MIDSLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) MIDSKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<MIDSKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) MIDSKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol MIDSKotlinx_coroutines_coreJob <MIDSKotlinCoroutineContextElement>
@required
- (id<MIDSKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<MIDSKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(MIDSKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (MIDSKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<MIDSKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(MIDSKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));
- (id<MIDSKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(MIDSKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<MIDSKotlinx_coroutines_coreJob>)plusOther_:(id<MIDSKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<MIDSKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<MIDSKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<MIDSKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface MIDSKtor_httpHttpStatusCode : MIDSBase <MIDSKotlinComparable>
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(MIDSKtor_httpHttpStatusCode *)other __attribute__((swift_name("compareTo(other:)")));
- (MIDSKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (MIDSKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface MIDSKtor_utilsGMTDate : MIDSBase <MIDSKotlinComparable>
@property (class, readonly, getter=companion) MIDSKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(MIDSKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (MIDSKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(MIDSKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(MIDSKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) MIDSKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) MIDSKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface MIDSKtor_httpHttpProtocolVersion : MIDSBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol MIDSKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<MIDSKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface MIDSKotlinAbstractCoroutineContextKey<B, E> : MIDSBase <MIDSKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<MIDSKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<MIDSKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface MIDSKotlinx_coroutines_coreCoroutineDispatcherKey : MIDSKotlinAbstractCoroutineContextKey<id<MIDSKotlinContinuationInterceptor>, MIDSKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<MIDSKotlinCoroutineContextKey>)baseKey safeCast:(id<MIDSKotlinCoroutineContextElement> _Nullable (^)(id<MIDSKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol MIDSKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol MIDSKtor_ioByteReadChannel
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(completionHandler:)")));
- (BOOL)cancelCause_:(MIDSKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)discardMax:(int64_t)max completionHandler:(void (^)(MIDSLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("discard(max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)peekToDestination:(MIDSKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max completionHandler:(void (^)(MIDSLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(MIDSKtor_ioChunkBuffer *)dst completionHandler:(void (^)(MIDSInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:completionHandler:)")));
- (int32_t)readAvailableMin:(int32_t)min block:(void (^)(MIDSKtor_ioBuffer *))block __attribute__((swift_name("readAvailable(min:block:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(MIDSKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(MIDSInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(MIDSInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(MIDSInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler__:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBooleanWithCompletionHandler:(void (^)(MIDSBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBoolean(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readByteWithCompletionHandler:(void (^)(MIDSByte * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readByte(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readDoubleWithCompletionHandler:(void (^)(MIDSDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readDouble(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFloatWithCompletionHandler:(void (^)(MIDSFloat * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFloat(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(MIDSKtor_ioChunkBuffer *)dst n:(int32_t)n completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:n:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(MIDSKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler__:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readIntWithCompletionHandler:(void (^)(MIDSInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readInt(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readLongWithCompletionHandler:(void (^)(MIDSLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readLong(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readPacketSize:(int32_t)size completionHandler:(void (^)(MIDSKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readPacket(size:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readRemainingLimit:(int64_t)limit completionHandler:(void (^)(MIDSKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readRemaining(limit:completionHandler:)")));
- (void)readSessionConsumer:(void (^)(id<MIDSKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readShortWithCompletionHandler:(void (^)(MIDSShort * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readShort(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readSuspendableSessionConsumer:(id<MIDSKotlinSuspendFunction1>)consumer completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readSuspendableSession(consumer:completionHandler:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineLimit:(int32_t)limit completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8Line(limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineToOut:(id<MIDSKotlinAppendable>)out limit:(int32_t)limit completionHandler:(void (^)(MIDSBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8LineTo(out:limit:completionHandler:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) MIDSKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol MIDSKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<MIDSKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<MIDSKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<MIDSKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<MIDSKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface MIDSKtor_utilsStringValuesBuilderImpl : MIDSBase <MIDSKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<MIDSKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<MIDSKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<MIDSKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<MIDSKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) MIDSMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface MIDSKtor_httpHeadersBuilder : MIDSKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<MIDSKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface MIDSKtor_client_coreHttpRequestBuilderCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface MIDSKtor_httpURLBuilder : MIDSBase
- (instancetype)initWithProtocol:(MIDSKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<MIDSKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<MIDSKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<MIDSKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property MIDSKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface MIDSKtor_utilsTypeInfo : MIDSBase
- (instancetype)initWithType:(id<MIDSKotlinKClass>)type reifiedType:(id<MIDSKotlinKType>)reifiedType kotlinType:(id<MIDSKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (MIDSKtor_utilsTypeInfo *)doCopyType:(id<MIDSKotlinKClass>)type reifiedType:(id<MIDSKotlinKType>)reifiedType kotlinType:(id<MIDSKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MIDSKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<MIDSKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<MIDSKotlinKClass> type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface MIDSKtor_client_coreHttpClientCallCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_utilsAttributeKey<id> *CustomResponse __attribute__((swift_name("CustomResponse"))) __attribute__((unavailable("This is going to be removed. Please file a ticket with clarification why and what for do you need it.")));
@end

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol MIDSKtor_client_coreHttpRequest <MIDSKtor_httpHttpMessage, MIDSKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<MIDSKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) MIDSKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) MIDSKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) MIDSKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) MIDSKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("KotlinAppendable")))
@protocol MIDSKotlinAppendable
@required
- (id<MIDSKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<MIDSKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<MIDSKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimePadding")))
@interface MIDSKotlinx_datetimePadding : MIDSKotlinEnum<MIDSKotlinx_datetimePadding *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSKotlinx_datetimePadding *none __attribute__((swift_name("none")));
@property (class, readonly) MIDSKotlinx_datetimePadding *zero __attribute__((swift_name("zero")));
@property (class, readonly) MIDSKotlinx_datetimePadding *space __attribute__((swift_name("space")));
+ (MIDSKotlinArray<MIDSKotlinx_datetimePadding *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSKotlinx_datetimePadding *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeekNames")))
@interface MIDSKotlinx_datetimeDayOfWeekNames : MIDSBase
- (instancetype)initWithNames:(NSArray<NSString *> *)names __attribute__((swift_name("init(names:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMonday:(NSString *)monday tuesday:(NSString *)tuesday wednesday:(NSString *)wednesday thursday:(NSString *)thursday friday:(NSString *)friday saturday:(NSString *)saturday sunday:(NSString *)sunday __attribute__((swift_name("init(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKotlinx_datetimeDayOfWeekNamesCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> *names __attribute__((swift_name("names")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonthNames")))
@interface MIDSKotlinx_datetimeMonthNames : MIDSBase
- (instancetype)initWithNames:(NSArray<NSString *> *)names __attribute__((swift_name("init(names:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithJanuary:(NSString *)january february:(NSString *)february march:(NSString *)march april:(NSString *)april may:(NSString *)may june:(NSString *)june july:(NSString *)july august:(NSString *)august september:(NSString *)september october:(NSString *)october november:(NSString *)november december:(NSString *)december __attribute__((swift_name("init(january:february:march:april:may:june:july:august:september:october:november:december:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKotlinx_datetimeMonthNamesCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> *names __attribute__((swift_name("names")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface MIDSKtor_httpUrlCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParameters")))
@protocol MIDSKtor_httpParameters <MIDSKtor_utilsStringValues>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface MIDSKtor_httpURLProtocol : MIDSBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface MIDSKtor_httpHttpMethodCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<MIDSKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) MIDSKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) MIDSKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) MIDSKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) MIDSKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) MIDSKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) MIDSKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) MIDSKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol MIDSKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value_ __attribute__((swift_name("value_")));
@end

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface MIDSKtor_httpHeaderValueWithParameters : MIDSBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<MIDSKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<MIDSKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface MIDSKtor_httpContentType : MIDSKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<MIDSKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<MIDSKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(MIDSKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (MIDSKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (MIDSKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol MIDSKotlinx_coroutines_coreChildHandle <MIDSKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(MIDSKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<MIDSKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol MIDSKotlinx_coroutines_coreChildJob <MIDSKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<MIDSKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol MIDSKotlinSequence
@required
- (id<MIDSKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol MIDSKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) MIDSKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<MIDSKotlinx_coroutines_coreSelectInstance>, id _Nullable, id _Nullable))(MIDSKotlinThrowable *) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id, id _Nullable, id _Nullable) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id, id<MIDSKotlinx_coroutines_coreSelectInstance>, id _Nullable) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol MIDSKotlinx_coroutines_coreSelectClause0 <MIDSKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface MIDSKtor_httpHttpStatusCodeCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) MIDSKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) MIDSKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) MIDSKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) MIDSKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) MIDSKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) MIDSKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) MIDSKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) MIDSKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) MIDSKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) MIDSKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) MIDSKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) MIDSKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) MIDSKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) MIDSKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) MIDSKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) MIDSKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) MIDSKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) MIDSKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) MIDSKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) MIDSKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) MIDSKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) MIDSKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) MIDSKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) MIDSKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) MIDSKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) MIDSKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) MIDSKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) MIDSKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) MIDSKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) MIDSKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) MIDSKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) MIDSKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) MIDSKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) MIDSKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) MIDSKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) MIDSKtor_httpHttpStatusCode *TooEarly __attribute__((swift_name("TooEarly")));
@property (readonly) MIDSKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) MIDSKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) MIDSKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) MIDSKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) MIDSKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) MIDSKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) MIDSKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) MIDSKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<MIDSKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface MIDSKtor_utilsGMTDateCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface MIDSKtor_utilsWeekDay : MIDSKotlinEnum<MIDSKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MIDSKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) MIDSKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) MIDSKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) MIDSKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) MIDSKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) MIDSKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) MIDSKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (MIDSKotlinArray<MIDSKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface MIDSKtor_utilsMonth : MIDSKotlinEnum<MIDSKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MIDSKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) MIDSKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) MIDSKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) MIDSKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) MIDSKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) MIDSKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) MIDSKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) MIDSKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) MIDSKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) MIDSKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) MIDSKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) MIDSKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (MIDSKotlinArray<MIDSKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface MIDSKtor_httpHttpProtocolVersionCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (MIDSKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) MIDSKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface MIDSKtor_ioMemory : MIDSBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKtor_ioMemoryCompanion *companion __attribute__((swift_name("companion")));
- (void)doCopyToDestination:(MIDSKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(MIDSKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (MIDSKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (MIDSKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end

__attribute__((swift_name("Ktor_ioBuffer")))
@interface MIDSKtor_ioBuffer : MIDSBase
- (instancetype)initWithMemory:(MIDSKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("\n    We're migrating to the new kotlinx-io library.\n    This declaration is deprecated and will be removed in Ktor 4.0.0\n    If you have any problems with migration, please contact us in \n    https://youtrack.jetbrains.com/issue/KTOR-6030/Migrate-to-new-kotlinx.io-library\n    ")));
@property (class, readonly, getter=companion) MIDSKtor_ioBufferCompanion *companion __attribute__((swift_name("companion")));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (MIDSKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)duplicateToCopy:(MIDSKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) MIDSKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface MIDSKtor_ioChunkBuffer : MIDSKtor_ioBuffer
- (instancetype)initWithMemory:(MIDSKtor_ioMemory *)memory origin:(MIDSKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<MIDSKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("\n    We're migrating to the new kotlinx-io library.\n    This declaration is deprecated and will be removed in Ktor 4.0.0\n    If you have any problems with migration, please contact us in \n    https://youtrack.jetbrains.com/issue/KTOR-6030/Migrate-to-new-kotlinx.io-library\n    ")));
- (instancetype)initWithMemory:(MIDSKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_ioChunkBufferCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (MIDSKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<MIDSKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next_) MIDSKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) MIDSKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end

__attribute__((swift_name("Ktor_ioInput")))
@interface MIDSKtor_ioInput : MIDSBase <MIDSKtor_ioCloseable>
- (instancetype)initWithHead:(MIDSKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<MIDSKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("\n    We're migrating to the new kotlinx-io library.\n    This declaration is deprecated and will be removed in Ktor 4.0.0\n    If you have any problems with migration, please contact us in \n    https://youtrack.jetbrains.com/issue/KTOR-6030/Migrate-to-new-kotlinx.io-library\n    ")));
@property (class, readonly, getter=companion) MIDSKtor_ioInputCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)canRead __attribute__((swift_name("canRead()")));
- (void)close __attribute__((swift_name("close()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (void)discardExactN:(int32_t)n __attribute__((swift_name("discardExact(n:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (MIDSKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (int32_t)fillDestination:(MIDSKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (BOOL)hasBytesN:(int32_t)n __attribute__((swift_name("hasBytes(n:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)markNoMoreChunksAvailable __attribute__((swift_name("markNoMoreChunksAvailable()")));
- (int32_t)peekToBuffer:(MIDSKtor_ioChunkBuffer *)buffer __attribute__((swift_name("peekTo(buffer:)")));
- (int64_t)peekToDestination:(MIDSKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (NSString *)readTextMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(min:max:)")));
- (int32_t)readTextOut:(id<MIDSKotlinAppendable>)out min:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(out:min:max:)")));
- (NSString *)readTextExactExactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(exactCharacters:)")));
- (void)readTextExactOut:(id<MIDSKotlinAppendable>)out exactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(out:exactCharacters:)")));
- (void)release_ __attribute__((swift_name("release()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@property (readonly) id<MIDSKtor_ioObjectPool> pool __attribute__((swift_name("pool")));
@property (readonly) int64_t remaining __attribute__((swift_name("remaining")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket")))
@interface MIDSKtor_ioByteReadPacket : MIDSKtor_ioInput
- (instancetype)initWithHead:(MIDSKtor_ioChunkBuffer *)head pool:(id<MIDSKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:pool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHead:(MIDSKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<MIDSKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MIDSKtor_ioByteReadPacketCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (MIDSKtor_ioByteReadPacket *)doCopy __attribute__((swift_name("doCopy()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (MIDSKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (int32_t)fillDestination:(MIDSKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol MIDSKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (MIDSKtor_ioChunkBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface MIDSKtor_httpURLBuilderCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol MIDSKtor_httpParametersBuilder <MIDSKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((swift_name("KotlinKType")))
@protocol MIDSKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<MIDSKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<MIDSKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeekNames.Companion")))
@interface MIDSKotlinx_datetimeDayOfWeekNamesCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinx_datetimeDayOfWeekNamesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKotlinx_datetimeDayOfWeekNames *ENGLISH_ABBREVIATED __attribute__((swift_name("ENGLISH_ABBREVIATED")));
@property (readonly) MIDSKotlinx_datetimeDayOfWeekNames *ENGLISH_FULL __attribute__((swift_name("ENGLISH_FULL")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonthNames.Companion")))
@interface MIDSKotlinx_datetimeMonthNamesCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinx_datetimeMonthNamesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKotlinx_datetimeMonthNames *ENGLISH_ABBREVIATED __attribute__((swift_name("ENGLISH_ABBREVIATED")));
@property (readonly) MIDSKotlinx_datetimeMonthNames *ENGLISH_FULL __attribute__((swift_name("ENGLISH_FULL")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface MIDSKtor_httpURLProtocolCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) MIDSKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) MIDSKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) MIDSKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) MIDSKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) MIDSKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, MIDSKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface MIDSKtor_httpHeaderValueParam : MIDSBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (MIDSKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface MIDSKtor_httpHeaderValueWithParametersCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<MIDSKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface MIDSKtor_httpContentTypeCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) MIDSKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol MIDSKotlinx_coroutines_coreParentJob <MIDSKotlinx_coroutines_coreJob>
@required
- (MIDSKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol MIDSKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<MIDSKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<MIDSKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface MIDSKtor_utilsWeekDayCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (MIDSKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface MIDSKtor_utilsMonthCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (MIDSKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (MIDSKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory.Companion")))
@interface MIDSKtor_ioMemoryCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_ioMemoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_ioMemory *Empty __attribute__((swift_name("Empty")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioBuffer.Companion")))
@interface MIDSKtor_ioBufferCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_ioBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_ioBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol MIDSKtor_ioObjectPool <MIDSKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioChunkBuffer.Companion")))
@interface MIDSKtor_ioChunkBufferCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_ioChunkBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_ioChunkBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<MIDSKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<MIDSKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioInput.Companion")))
@interface MIDSKtor_ioInputCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_ioInputCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket.Companion")))
@interface MIDSKtor_ioByteReadPacketCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKtor_ioByteReadPacketCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MIDSKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface MIDSKotlinKTypeProjection : MIDSBase
- (instancetype)initWithVariance:(MIDSKotlinKVariance * _Nullable)variance type:(id<MIDSKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MIDSKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (MIDSKotlinKTypeProjection *)doCopyVariance:(MIDSKotlinKVariance * _Nullable)variance type:(id<MIDSKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<MIDSKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) MIDSKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface MIDSKotlinKVariance : MIDSKotlinEnum<MIDSKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MIDSKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) MIDSKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) MIDSKotlinKVariance *out __attribute__((swift_name("out")));
+ (MIDSKotlinArray<MIDSKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MIDSKotlinKVariance *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface MIDSKotlinKTypeProjectionCompanion : MIDSBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MIDSKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (MIDSKotlinKTypeProjection *)contravariantType:(id<MIDSKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (MIDSKotlinKTypeProjection *)covariantType:(id<MIDSKotlinKType>)type __attribute__((swift_name("covariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (MIDSKotlinKTypeProjection *)invariantType:(id<MIDSKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) MIDSKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
